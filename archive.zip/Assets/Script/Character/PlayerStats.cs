using UnityEngine;

namespace Script.Character
{
    public class PlayerStats : MonoBehaviour
    {
        public int maxHealth = 100;
        public float speed = 10;
    }
}