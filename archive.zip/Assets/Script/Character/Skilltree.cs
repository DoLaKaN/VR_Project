using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Skilltree : MonoBehaviour
{
    public GameObject[] skils;
    public GameObject skillTreeWindow;


    public Button skillButton1;
    public Button skillButton2;
    public Button skillButton3;
    public Text skillText1;
    public Text skillText2;
    public Text skillText3;
    
    void Start()
    {
        ShowSkillTree();
    }

    void Update()
    {
        
    }


    void SkillTreeWindow()
    {




    }

    void HideSkillTree()
    {
        skillTreeWindow?.SetActive(false);
    }

    void ShowSkillTree()
    {
        skillTreeWindow?.SetActive(true);
    }

}
