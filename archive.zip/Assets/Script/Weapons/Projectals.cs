using Script.Health;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using Unity.VisualScripting;
using UnityEngine;

public class Projectals : MonoBehaviour
{
    public int damage;
    public float speed;
    public float cooldown;
    public float LiveTime;
    public float size;
    public int penetration;

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Enemy"))
        {
            var Enemy = other.gameObject.GetComponent<EnemyHealthAttribute>();
            Enemy.DealDamage(damage);
            if (penetration >= 1)
            {
                //Enemy.DealDamage(damage);
                penetration -= 1;
            }
            if (penetration == 0) {
                //Enemy.DealDamage(damage);
                Destroy(this.gameObject);
            }

        }
    }

}

